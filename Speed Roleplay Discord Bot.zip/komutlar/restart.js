const Discord = require("discord.js");
const db = require("nrc.db")
const {MessageActionRow, MessageButton} = require("discord.js")
module.exports = {
    calistir: async(client, message, args) => {
        if(message.author.id !== "1065880112299520030"){
              return message.reply("sen kullanaman essek");
        } else {
    const aktifEmbed = new Discord.MessageEmbed()
        .setColor("GREEN")
        .setTitle("**Sunucumuza restart atılıyor en kısa zamanda tekrardan aktif olacaktır.**")
        .setThumbnail(client.user.avatarURL({dynamic: true, type: 'png'}))
        .setTimestamp()
        message.channel.send({content: "||@everyone||", embeds: [aktifEmbed]})
}    
},

name: "restart",
description: "",
aliases: [],
kategori: "",
usage: "",
}
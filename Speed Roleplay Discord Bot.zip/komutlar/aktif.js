﻿const Discord = require("discord.js");
const db = require("nrc.db")
const {MessageActionRow, MessageButton} = require("discord.js")
module.exports = {
    calistir: async(client, message, args) => {
        if(message.author.id !== "1065880112299520030"|| message.author.id == "1033713347817914518"){
              return message.reply("sen kullanaman essek");
        } else {
    const aktifEmbed = new Discord.MessageEmbed()
        .setColor("GREEN")
        .setTitle("**Sunucumuz sorunsuz şekilde aktif edilmiştir. \nAktif olan herkesi sunucumuza bekliyoruz. \nSunucu IP Adresimiz: 'mtasa://185.255.95.193:22003'**")
        .setThumbnail(client.user.avatarURL({dynamic: true, type: 'png'}))
        .setImage("https://media.discordapp.net/attachments/880810605773209691/912324845121990726/aktif.gif")
        .setTimestamp()
        message.channel.send({content: "||@everyone||", embeds: [aktifEmbed]})
}    
},

name: "aktif",
description: "",
aliases: [],
kategori: "",
usage: "",
}